import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('cassidy_test')

def lambda_handler(event, context):
    file_name = event["queryStringParameters"]['file_name']
    response = table.get_item(
        Key={
            'file_name': file_name
        }
    )
    
    return {
        "isBase64Encoded": False,  
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*" 
        },
       "body": json.dumps(response['Item'])
    }
