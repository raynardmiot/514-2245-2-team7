import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')
table_name = "CatImageLabels"
table = dynamodb.Table(table_name)


def lambda_handler(event, context):
    file_name = event["queryStringParameters"]['file_name']
    response = table.get_item(
        Key={
            'Key': file_name
        }
    )
    
    return {
        "isBase64Encoded": False,  
        "statusCode": 200,
        "headers": {
             "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
                "Access-Control-Allow-Headers": "Content-Type"
        },
       "body": json.dumps(response['Item'])
    }
