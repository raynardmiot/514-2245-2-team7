import json
import boto3
import uuid

print('Loading function')

s3 = boto3.client('s3')
BUCKET_NAME = '514-team7-testing-bucket'

def lambda_handler(event, context):
    image_id = str(uuid.uuid4())  
    key = f"{uuid.uuid4()}.jpg"   

    upload_url = s3.generate_presigned_url(
        'put_object',
        Params={
            'Bucket': BUCKET_NAME, 
            'Key': key,
            'ContentType': 'image/jpeg' 
          
        },
        ExpiresIn=3600
    )

    return {
        "isBase64Encoded": False,  
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type",
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*" 
        },
        "body": json.dumps({
            "imageId": image_id,
            "url": upload_url
        })
    }

